---
name: Modern Industrial Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#5a4138'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#8e7166'
  outline-variant: '#e2bfb2'
  surface-tint: '#a73a00'
  primary: '#a33900'
  on-primary: '#ffffff'
  primary-container: '#cc4900'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb599'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#0051d5'
  on-tertiary: '#ffffff'
  tertiary-container: '#316bf3'
  on-tertiary-container: '#fefcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb599'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#7f2b00'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
  data-metric:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  layout-gutter-mobile: 1rem
  layout-gutter-desktop: 1.5rem
  sidebar-width-collapsed: 4.5rem
  sidebar-width-expanded: 16rem
  max-content-width: 90rem
---

## Brand & Style

This design system establishes a high-precision, structural aesthetic engineered for general contractors, site superintendents, project managers, and specialty trades. The visual language bridges heavy civil durability with modern enterprise software sophistication—translating job-site clarity, architectural blueprints, and industrial safety markers into an intuitive digital environment.

The design movement combines **Corporate Modern** architectural precision with **Industrial Tactile Utility**:
- **Rugged Reliability:** Interfaces rely on strong structural framing, authoritative borders, clear demarcations, and dependable contrast ratios designed to withstand high-glare field conditions on tablets and phones.
- **Architectural Clarity:** Layouts favor clear spatial modules, dense tabular data displays, strict baseline alignment, and zero superfluous decoration.
- **Urgent Hierarchy:** Safety amber, alert vermilion, and blueprint cobalt puncture deep slate-charcoal anchor panels, guiding operational workflows with unambiguous visual priority.

## Colors

The color palette leverages an industrial hierarchy where structural foundations are anchored in deep architectural slates, work surfaces remain high-contrast bone and slate-tinted whites, and functional interactions pop with standard construction safety accents.

### Palette Architecture
- **Primary Industrial Accent (`#EA580C` - Safety Forge Orange):** Applied strictly to primary actions, completion triggers, punch-list authorizations, and high-priority states. A complementary warning amber (`#F59E0B`) serves secondary warnings, pending approvals, and timeline friction states.
- **Anchor Neutral & Chrome (`#0F172A` - Foundation Slate & `#1E293B` - Steel Charcoal):** Grounds the global navigation bars, persistent app shell, master table headers, and high-impact structural UI modules.
- **Action & Specification Blue (`#2563EB` - Blueprint Blue):** Dedicated to technical data links, blueprint markups, active tab indicators, and informational triggers.
- **Work Surfaces:** Canvas background rests on `#F8FAFC` (Slate Tint Neutral), while elevated cards, sheets, and data tables occupy `#FFFFFF`. Surface borders employ `#E2E8F0` and `#CBD5E1` for firm architectural delineation.
- **Financial & Schedule Indicators:** 
  - Over-budget / Safety Hazard: `#DC2626`
  - On-schedule / Margin Gain: `#16A34A`
  - Neutral Hold / Pending Submittal: `#64748B`

## Typography

The typographic hierarchy utilizes **Plus Jakarta Sans** for structural headers and section markers, leveraging its geometric precision, crisp legibility, and technical confidence.

**Inter** is configured for all interactive labels, form fields, and dense tabular data.
- **Tabular Figures:** Ensure all numerical displays—estimates, schedules, change orders, and line items—utilize `font-variant-numeric: tabular-nums` to ensure exact column-wise decimal alignment.
- **Stage & Phase Badges:** Stage indicators and section categorizations use `label-sm` rendered in uppercase with subtle letter-spacing for quick scannability across field devices.
- **Contrast Ratios:** Avoid muted gray body text on field viewports; secondary typography must never drop below `#475569` against light backgrounds.

## Layout & Spacing

The layout is built on a high-density 8pt base grid system designed for data throughput and field ergonomics.

### Layout Model
- **Application Shell:** Features a persistent dark navigation rail (`#0F172A`), collapsing to an icon-only dock or bottom navigation sheet on handheld mobile viewports.
- **Dashboard & Work Surfaces:** 12-column responsive fluid grid inside a 1440px (`90rem`) maximum wrapper. 
  - Desktop: 24px (`1.5rem`) gutters, 32px page margins.
  - Tablet (768px – 1024px): 16px gutters, 20px page margins, collapsing financial panels into stacked 6-column pairs.
  - Mobile (<768px): 12px gutters, 16px safe margins, with single-column structural stacking for daily logs, punch lists, and task boards.
- **Vertical Rhythm:** Tight 4px/8px increments between labels and inputs; generous 24px/32px section gaps between major specification groups.

## Elevation & Depth

Visual hierarchy does not rely on soft, decorative shadows. Instead, it employs **structural outlines and disciplined architectural planes**:

1. **Surface Layers (Tonal Planarity):**
   - **Level 0 (Canvas):** `#F8FAFC` base backdrop.
   - **Level 1 (Card & Module Foundation):** `#FFFFFF` surfaces bounded by a crisp 1px solid `#E2E8F0` border.
   - **Level 2 (Active Sheets, Drawers, Flyouts):** `#FFFFFF` backed by an ultra-clean, minimal structural shadow: `0 4px 12px -2px rgba(15, 23, 42, 0.08), 0 2px 4px -1px rgba(15, 23, 42, 0.04)` paired with `#CBD5E1` bordering.
   - **Level 3 (Modal Dialogs & Critical Overlays):** `#FFFFFF` backed by `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.08)` over a dark `#0F172A` backdrop at 65% opacity.

2. **Divider Philosophy:** 
   - Heavy structural breaks use 2px solid `#E2E8F0`. 
   - Subtle inner-table dividers use 1px solid `#F1F5F9`.

## Shapes

The design system maintains a **Soft-Chiseled Industrial Profile** (`roundedness: 1`):
- Standard interaction elements (buttons, inputs, cards, table wrappers) feature **4px (`0.25rem`)** corners.
- Segmented sheets, modals, and container groupings feature **8px (`0.5rem`)** corners.
- Pill badges (`9999px`) are intentionally avoided for main structural UI to eliminate an overly consumer-app feel, with the exception of status pips and compact stage indicators which utilize a restrained **4px** rounded corner.
- Structural tabs, header bars, and progress tracks maintain clean, planar, squared boundaries.

## Components

### Buttons
- **Primary (Orange Forge):** Solid `#EA580C` background, white bold text, 4px border-radius, 40px height for desktop (48px for field touch targets). Hover state darkens to `#C2410C`. Active state presses down with a subtle inner border.
- **Secondary (Steel Outline):** White background, 1px solid `#CBD5E1` border, `#0F172A` text. Hover transitions background to `#F8FAFC` with border `#94A3B8`.
- **Tertiary / Blueprint:** Transparent background with `#2563EB` text; hover reveals `#EFF6FF` background.
- **Danger / Stop-Work:** Solid `#DC2626` background, `#FFFFFF` text, applied to destructive deletions or hazard reports.

### Stage & Phase Badges
Compact rectangular indicators (4px radius, uppercase `label-sm` font, 4px vertical / 8px horizontal padding):
- **Demo:** Background `#F1F5F9`, Text `#475569`, Border `#CBD5E1`.
- **Framing:** Background `#FEF3C7`, Text `#B45309`, Border `#FDE68A`.
- **MEP (Mechanical/Electrical/Plumbing):** Background `#DBEAFE`, Text `#1D4ED8`, Border `#BFDBFE`.
- **Trim:** Background `#F3E8FF`, Text `#6B21A8`, Border `#E9D5FF`.
- **Final:** Background `#DCFCE7`, Text `#15803D`, Border `#BBF7D0`.

### Data Tables & Spec Sheets
- **Header Row:** Deep Slate `#1E293B` or crisp light `#F1F5F9` with `#475569` bold uppercase micro-text.
- **Rows:** Minimum height 48px, alternating hover state `#F8FAFC`. 1px horizontal borders in `#E2E8F0`.
- **Financial Cells:** Right-aligned tabular numbers. Positive budget variances render `#16A34A`; cost overruns render bold `#DC2626` with explicit `+` and `-` signs.

### Input Fields & Controls
- **Text Inputs & Dropdowns:** 40px height (48px touch targets), 1px solid `#CBD5E1` border, `#FFFFFF` background. Focus state: 1px `#2563EB` ring with 2px offset.
- **Checkboxes & Radios:** Chiseled 4px boundary on checkboxes, 2px border `#94A3B8`, checking into solid `#EA580C` or `#2563EB` with bold white checkmark.

### Cards & Progress Modules
- Master project cards feature an elevated `#FFFFFF` container with a top architectural stripe: 4px solid line color-coded by project phase or schedule health.
- Internal progress bars are 8px tall, flat `#E2E8F0` track, with `#EA580C` or `#16A34A` fill.