---
name: Atelier Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#9b4500'
  on-secondary: '#ffffff'
  secondary-container: '#fd8a42'
  on-secondary-container: '#682c00'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002114'
  on-tertiary-container: '#069669'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#ffdbca'
  secondary-fixed-dim: '#ffb68e'
  on-secondary-fixed: '#331200'
  on-secondary-fixed-variant: '#763300'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: '0'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
  screen-edge-padding: 1.25rem
  card-inner-padding: 1.25rem
  touch-target-min: 3rem
---

## Brand & Style

This design system is engineered for the elite independent general contractor, master artisan, and high-end residential renovation specialist. These users manage seven-figure project portfolios alone—often reviewing line items, drawing markups, change orders, and sub-draws directly from active, high-tempo job sites.

The visual direction marries the computational restraint of Linear, the physical materiality and precision of Apple industrial design, and the financial composure of Stripe. It projects absolute competence, quiet luxury, and architectural permanence. 

Key attributes:
- **Tone:** Architectural, calm, hyper-composed, uncompromisingly focused.
- **Form Language:** Crisp 1px structural framing, immaculate micro-whitespace, high-density glanceability without clutter, and heavy tactile surfaces.
- **Aesthetic Movement:** Modern Minimalist with bespoke luxury tactile accents. Surfaces feel like sand-cast anodized aluminum and honed Belgian slate, delivering high-contrast readability under direct outdoor sunlight and low-light job trailers.

## Colors

The palette balances clean mineral whites and architectural graphite with high-intent metallic and functional accents.

- **Primary (`#0f172a` / Deep Obsidian Slate):** Anchors primary brand marks, primary CTA blocks, key headers, and critical numeric values. Represents structural integrity.
- **Secondary (`#b45309` / Warm Burnished Bronze):** Used sparingly as an accent for active phase indicators, critical project milestones, bid acceptance states, and high-touch badge highlights.
- **Tertiary (`#059669` / Precision Emerald):** Strictly assigned to fiscal health—cleared draws, positive cashflow velocity, signed contract confirmations, and on-schedule variance.
- **Neutral (`#64748b` / Architectural Slate):** Governs secondary metadata, dimensional specs, timestamps, and resting state iconography.
- **Base Surfaces:** 
  - Canvas: `#f8fafc` (Ultra-light bleached slate)
  - Card/Module Surface: `#ffffff` (Pure optical white)
  - Elevated Popovers/Drawers: `#ffffff` with structural `#e2e8f0` edge containment
- **Borders & Dividers:** Crisp, hairline `1px solid rgba(15, 23, 42, 0.08)` or `#e2e8f0` to establish structural order without visual weight.

## Typography

Typography prioritizes extreme legible structure under stressful operational conditions. 

- **Display & Body (`Plus Jakarta Sans`):** Selected for its geometric balance, humanized warmth, and distinct clarity in small-format user interfaces. Tightly tracked letter spacing (`-0.01em` to `-0.03em`) produces an authoritative architectural weight similar to bespoke high-end editorial layouts.
- **Data, Financials & Tags (`JetBrains Mono`):** Applied to monetary values, stage codes, square footage measurements, task IDs, and timeline durations. Monospaced rendering ensures numerical figures remain aligned across stacked rows during budget reviews.

## Layout & Spacing

The layout is built around a vertical stream optimized for single-hand thumb navigation on mobile viewports.

- **Grid Strategy:** Contextual fluid mobile column system with strict edge safe-zones. Primary horizontal gutter margins are fixed at `1.25rem` (`20px`) to prevent edge tap errors and provide structural breathing room.
- **Rhythm:** An 8-point base spatial system scaled down to 4px for micro-adjustments (`space-2xs`).
- **Touch Ergonomics:** High-priority interactive targets enforce a minimum height of `48px` (`3rem`), ensuring precision when utilized with gloved or dust-covered hands on active sites.
- **Breakpoint Scaling:**
  - Mobile (Default: `375px` to `428px`): Unified single-column card cascade with docked bottom execution sheets.
  - Tablet (`768px`+): Master-detail split view (340px pinned sidebar navigation, responsive canvas workspace).

## Elevation & Depth

Visual hierarchy uses crisp boundary containment over artificial atmospheric drop shadows:

- **Surface Layering:** Pure `#ffffff` interactive cards sit elevated against the `#f8fafc` architectural background. Layering is primarily generated through tonal separation rather than vertical blur.
- **The 1-Pixel Micro-Stroke:** Every surface container, modal bottom sheet, and badge features a `1px` crisp outline (`rgba(15, 23, 42, 0.08)`). This simulates precision-milled physical panels.
- **Tactile Shadows:** Restricted strictly to floating action elements and bottom navigation sheets. Implemented as an ambient dual-layer shadow:
  - Specular: `0 1px 2px rgba(15, 23, 42, 0.04)`
  - Ambient: `0 12px 24px -6px rgba(15, 23, 42, 0.06)`
- **Active State Depths:** Pressed states do not elevate; they depress slightly inward via subtle interior scale (`0.985`) and subtle edge darkening.

## Shapes

The design system uses deliberate corner radii to create an architectural, modern feel:

- **Cards & Primary Modules:** Enforce `1rem` to `1.5rem` (`rounded-2xl`, 16px–24px) corners. This softens the high density of financial and scheduling data.
- **Controls & Form Inputs:** Set to `0.5rem` (`rounded-lg`, 8px) to balance friendly card curves with disciplined, tool-like internal controls.
- **Status Tags & Micro-Badges:** Fully radiused (`pill` / 9999px) to immediately distinguish metadata chips from structural cards.

## Components

### Buttons
- **Primary:** `#0f172a` background, `#ffffff` typography, `12px` vertical padding, `rounded-xl`. High-contrast, assertive, and solid. No heavy drop shadow.
- **Secondary / Actionable Neutral:** `#ffffff` surface with `1px solid rgba(15, 23, 42, 0.12)`, `#0f172a` text.
- **Accent (Milestone / Signoff):** Deep bronze `#b45309` with `#ffffff` text, reserved for critical user transitions (e.g., "Send Change Order", "Authorize Draw").

### Cards & Modules
- Primary units for jobs, estimates, and daily site logs.
- Background: `#ffffff`, Border: `1px solid rgba(15, 23, 42, 0.07)`, Radius: `1rem` (16px).
- Internal layout: Upper meta-band featuring the client or site address, followed by a primary metric block (using `JetBrains Mono`), finalized with a status indicator along the bottom boundary.

### Status Chips & Progress Indicators
- Enclosed pill contours (`padding: 4px 10px`).
- **Financial Positive / Paid:** `#ecfdf5` (emerald-50) fill, `#059669` text, `1px solid rgba(5, 150, 105, 0.2)`.
- **In-Progress / Pending Verification:** `#fffbeb` (amber-50) fill, `#b45309` text, `1px solid rgba(180, 83, 9, 0.2)`.
- **Scheduled / Material En Route:** `#f1f5f9` (slate-100) fill, `#475569` text, `1px solid #e2e8f0`.

### Form Fields & Measurement Inputs
- Background: `#ffffff`.
- Border: `1px solid #cbd5e1`, shifting to `#0f172a` with a 2px focus ring on activation.
- Numerical fields display unit identifiers (e.g., `SQ FT`, `LNFT`, `USD`) right-aligned using `JetBrains Mono`.

### Quick Capture Drawer (Mobile Job Log)
- Bottom-pinned sheet with `rounded-t-3xl` radii, guarded by a top grab bar (`36px x 4px`, `#cbd5e1`).
- Designed for rapid single-handed thumb input of job site notes, material receipts, and voice-to-text punch-list items.